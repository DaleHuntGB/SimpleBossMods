# Simple BossMods

## [52563d5](https://github.com/ZapaNOR/SimpleBossMods/tree/52563d5c8cea7ec1cf031a92d91f1bb3ef3755fb) (2026-01-18)
[Full Changelog](https://github.com/ZapaNOR/SimpleBossMods/commits/52563d5c8cea7ec1cf031a92d91f1bb3ef3755fb) 

- Now release works!  
- Another test release  
- release test  
- initial commit  
