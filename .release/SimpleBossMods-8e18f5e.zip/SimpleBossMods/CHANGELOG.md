# Simple BossMods

## [8e18f5e](https://github.com/ZapaNOR/SimpleBossMods/tree/8e18f5eaabf34db275fea05abfcf8f9cef01e461) (2026-01-18)
[Full Changelog](https://github.com/ZapaNOR/SimpleBossMods/commits/8e18f5eaabf34db275fea05abfcf8f9cef01e461) 

- release test  
- initial commit  
